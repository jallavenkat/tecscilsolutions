
        <!-- footer content -->
        <footer>
          <div class="pull-right">
            
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    
    <!-- Bootstrap -->
    <script src="<?php echo base_url();?>uifiles/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url();?>uifiles/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url();?>uifiles/nprogress/nprogress.js"></script>
    <script src="<?php echo base_url();?>uifiles/DateJS/build/date.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="<?php echo base_url();?>uifiles/moment/min/moment.min.js"></script>
    <script src="<?php echo base_url();?>uifiles/bootstrap-daterangepicker/daterangepicker.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url();?>uifiles/build/js/custom.min.js"></script>
    <script src="<?php echo base_url();?>uifiles/js/venjos.js"></script>

  </body>
</html>