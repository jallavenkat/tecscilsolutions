<header class="in-page text-center text-white d-flex" style="background-image: url('<?php echo base_url();?>dist/img/portfolio.jpg');">
	<div class="banneroverly"></div>
  <div class="container my-auto topindex">
	<div class="row">
	  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mx-auto b-content">
		<h1 class="fweight100">
		  <strong>Web Design Company in Hyderabad</strong>
		</h1>
		<hr>
	  </div>
	  <div class="col-lg-8 mx-auto">
		<p class="text-faded mb-5">&nbsp;</p>
		<!--<a class="btn btn-primary btn-xl js-scroll-trigger" href="#about">Find Out More</a>-->
	  </div>
	</div>
	<div class="row">
	
	</div>
  </div>
</header>
<section class="p-0 py-0">
	<div class="container py-sm-4">
		<div class="welcome-grids row">
			<div class="col-lg-12 mb-lg-0 mb-5">
				<h3 class="mt-lg-0 txtCenter logoClrCon">
					Our Portfolio
				</h3>
			</div>
		</div>
	</div>
      <div class="container-fluid p-0">
		
        <div class="row no-gutters popup-gallery">
          <div class="col-lg-4 col-sm-6">
            <a class="portfolio-box" href="<?php echo base_url();?>dist/img/portfolio/fullsize/AnthemLeather.jpg">
              <img class="img-fluid" src="<?php echo base_url();?>dist/img/portfolio/thumbnails/AnthemLeather.jpg" alt="">
              <div class="portfolio-box-caption">
                <div class="portfolio-box-caption-content">
                  <div class="project-category text-faded">
                    Category
                  </div>
                  <div class="project-name">
                    Project Name
                  </div>
                </div>
              </div>
            </a>
          </div>
          <div class="col-lg-4 col-sm-6">
            <a class="portfolio-box" href="<?php echo base_url();?>dist/img/portfolio/fullsize/fortcal.jpg">
              <img class="img-fluid" src="<?php echo base_url();?>dist/img/portfolio/thumbnails/fortcal.jpg" alt="">
              <div class="portfolio-box-caption">
                <div class="portfolio-box-caption-content">
                  <div class="project-category text-faded">
                    Category
                  </div>
                  <div class="project-name">
                    Project Name
                  </div>
                </div>
              </div>
            </a>
          </div>
          <div class="col-lg-4 col-sm-6">
            <a class="portfolio-box" href="<?php echo base_url();?>dist/img/portfolio/fullsize/ManagedTech_v1.jpg">
              <img class="img-fluid" src="<?php echo base_url();?>dist/img/portfolio/thumbnails/ManagedTech_v1.jpg" alt="">
              <div class="portfolio-box-caption">
                <div class="portfolio-box-caption-content">
                  <div class="project-category text-faded">
                    Category
                  </div>
                  <div class="project-name">
                    Project Name
                  </div>
                </div>
              </div>
            </a>
          </div>
          <div class="col-lg-4 col-sm-6">
            <a class="portfolio-box" href="<?php echo base_url();?>dist/img/portfolio/fullsize/NinaTulio_V1.jpg">
              <img class="img-fluid" src="<?php echo base_url();?>dist/img/portfolio/thumbnails/NinaTulio_V1.jpg" alt="">
              <div class="portfolio-box-caption">
                <div class="portfolio-box-caption-content">
                  <div class="project-category text-faded">
                    Category
                  </div>
                  <div class="project-name">
                    Project Name
                  </div>
                </div>
              </div>
            </a>
          </div>
          <div class="col-lg-4 col-sm-6">
            <a class="portfolio-box" href="<?php echo base_url();?>dist/img/portfolio/fullsize/Workhousenyc_v1.jpg">
              <img class="img-fluid" src="<?php echo base_url();?>dist/img/portfolio/thumbnails/Workhousenyc_v1.jpg" alt="">
              <div class="portfolio-box-caption">
                <div class="portfolio-box-caption-content">
                  <div class="project-category text-faded">
                    Category
                  </div>
                  <div class="project-name">
                    Project Name
                  </div>
                </div>
              </div>
            </a>
          </div>
          <div class="col-lg-4 col-sm-6">
            <a class="portfolio-box" href="<?php echo base_url();?>dist/img/portfolio/fullsize/Yumoi.jpg">
              <img class="img-fluid" src="<?php echo base_url();?>dist/img/portfolio/thumbnails/Yumoi.jpg" alt="">
              <div class="portfolio-box-caption">
                <div class="portfolio-box-caption-content">
                  <div class="project-category text-faded">
                    Category
                  </div>
                  <div class="project-name">
                    Project Name
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </section>
